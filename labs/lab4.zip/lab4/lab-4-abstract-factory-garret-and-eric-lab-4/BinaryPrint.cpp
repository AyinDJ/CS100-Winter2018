#include "BinaryPrint.h"

void BinaryPrint::print(){
	bitset<16> output (value);
	cout << output<< endl;
}