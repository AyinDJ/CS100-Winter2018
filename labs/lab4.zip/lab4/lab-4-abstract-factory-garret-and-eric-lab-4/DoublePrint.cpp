#include <iostream>

#include "DoublePrint.h"

using namespace std;

void DoublePrint::print() {
	cout << value << endl;
}