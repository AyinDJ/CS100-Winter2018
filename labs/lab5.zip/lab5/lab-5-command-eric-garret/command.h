#ifndef __COMMAND_CLASS__
#define __COMMAND_CLASS__

#include "composite.h"

class Command {
	protected:
		Base* root;
	
	public:
		Command() { };
		virtual double execute() {
			return root->evaluate();
		};
		Base* get_root() {
			return root;
		};
};

class OpCommand : public Command {
	//OpCommand Code Here
	public:
		OpCommand(double val){ root = new Op(val); };
		double execute();
		Base* get_root();
};

class AddCommand : public Command {
	//AddCommand Code Here
	public:
		AddCommand(Command* c, double val){ root=new Add(c->get_root(), new Op(val));};
		double execute();
		Base* get_root();
};

class SubCommand : public Command {
	//SubCommand Code Here
	public:
		SubCommand(Command* c, double val){root=new Sub(c->get_root(), new Op(val));};
		double execute();
		Base* get_root();
};

class MultCommand : public Command {
	//MultCommand Code Here
	public:
		MultCommand(Command* c, double val){root=new Mult(c->get_root(), new Op(val));};
		double execute();
		Base* get_root();
};

class SqrCommand : public Command {
	//SqrCommand Code Here
	public:
		SqrCommand(Command* c){root=new Sqr(c->get_root());};
		double execute();
		Base* get_root();
};

#endif //__COMMAND_CLASS__
