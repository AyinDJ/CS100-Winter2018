#include <iostream>
#include "menu.h"
#include "command.h"

using namespace std;

void Menu::execute() {
	if (history.at(history_index) == NULL) {
		cout << 0 << endl;;
		return;
	}
	cout << history.at(history_index)->execute() << endl;
	// cout << "History index after executing: " << history_index << endl;

	// if (history_index - 1 == 0) {
	// 	cout << "First command's result is: " << history.at(history_index)->execute() << endl;
	// }
	// else {
	// 	cout << "Previous command's result is: " << history.at(history_index - 1)->execute() << endl;
	// }

	// if (history_index + 1 == history.size()) {
	// 	cout << "Last command's result is: " << history.at(history_index)->execute() << endl;
	// }
	// else {
	// 	cout << "Next command's result is: " << history.at(history_index + 1)->execute() << endl;
	// }
}

bool Menu::initialized() {
	// cout << "History index: " << history_index << endl;
	if (history_index == 0) {
		return false;
	}
	return true;
}

void Menu::add_command(Command* cmd) {
	// cout << "Start add command" << endl;
	vector<Command*>::iterator it = history.begin();
	int counter = history_index + 1;

	if (history.empty()) {
		// cout << "Pushing back 0" << endl;
		history.push_back(NULL);
		// cout << "Pushing back" << endl;
		history.push_back(cmd);
		// cout << "Push back successful" << endl;
		++history_index;
	}
	else {
		if (history_index == history.size() - 1) {
			// cout << "Pushing back" << endl;
			history.push_back(cmd);
			++history_index;
		}
		else {
			while (counter != 0) {
				++it;
				--counter;
			}
			// cout << "Inserting" << endl;
			// history.insert(it, cmd);
			// ++history_index;
			// ++it;
			// cout << "Erasing: " << (*it)->execute() << endl;
			// history.erase(it);
			history.at(history_index + 1) = cmd;
			++history_index;
		}
	}
}

Command* Menu::get_command() {
	return history.at(history_index);
}

void Menu::undo() {
	if (history_index == 0) {
		// cout << "Returning history index" << endl;
		return;
	}
	--history_index;
	// cout << "History index after undoing: " << history_index << endl;
}

void Menu::redo() {
	if (history_index == history.size() - 1) {
		return;
	}
	history_index++;
}