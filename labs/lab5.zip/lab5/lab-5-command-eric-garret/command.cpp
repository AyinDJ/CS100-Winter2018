#include "command.h"

double OpCommand::execute(){
	return root->evaluate();
}

Base* OpCommand::get_root(){
	return root;
}

double AddCommand::execute(){
	return root->evaluate();
}

Base* AddCommand::get_root(){
	return root;
}

double SubCommand::execute(){
	return root->evaluate();
}

Base* SubCommand::get_root(){
	return root;
}

double MultCommand::execute(){
	return root->evaluate();
}

Base* MultCommand::get_root(){
	return root;
}

double SqrCommand::execute(){
	return root->evaluate();
}

Base* SqrCommand::get_root(){
	return root;
}

